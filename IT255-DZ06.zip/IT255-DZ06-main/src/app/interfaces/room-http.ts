export interface RoomHttp {
    rooms: []
}
