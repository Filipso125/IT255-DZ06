export interface Room {
  id: number;
    room: number;
    floor:number;
    price: number;
    nights: number;
    desc: string;
}
